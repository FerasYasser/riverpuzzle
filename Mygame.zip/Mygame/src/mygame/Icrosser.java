/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mygame;

import javafx.scene.image.Image;

/**
 *
 * @author feras
 */
public class Icrosser {
    Image image;
     static double positionX;
    static double positionY;
    private double width;
    private double height;
    static double deltaX;
    static double deltaY;
    int idx;
    int eatingRank;
    
}
