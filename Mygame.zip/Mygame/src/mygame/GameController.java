/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mygame;

import java.util.List;

/**
 *
 * @author feras
 */
public interface GameController {
   public List<Icrosser> getInitials();
   public List<Icrosser2> getInitials1();
   public List<Icrosser> rightSide1();
   public List<Icrosser> leftSide();
   public List<Icrosser2> rightSide2();
   public List<Icrosser2> leftSide1();
   
}
